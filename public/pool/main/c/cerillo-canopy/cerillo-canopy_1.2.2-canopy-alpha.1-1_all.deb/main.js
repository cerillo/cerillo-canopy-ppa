#!/usr/bin/env node
"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const CanopyFirmware_1 = require("./CanopyFirmware");
const chalk_1 = __importDefault(require("chalk"));
const figlet = __importStar(require("figlet"));
const conf_1 = __importDefault(require("conf"));
const commander_1 = require("commander");
const program = new commander_1.Command();
const logger_1 = require("@cerillo/logger");
const version_1 = require("./version");
const clear_1 = __importDefault(require("clear"));
const font = 'Basic';
const child_process_1 = require("child_process");
const path_1 = require("path");
// load config
const UART_PORT = '/dev/serial0';
const USBC_PORT = '/dev/ttyGS0';
const CANOPY_CONFIG_DEFAULTS = {
    id: {
        serialNumber: '',
        modelNumber: 'CanopyR1',
    },
    xbee: {
        path: UART_PORT,
        panId: '0',
        baudRate: 115200,
    },
    serial: {
        path: USBC_PORT,
        baudRate: 250000,
    },
    settings: {
        name: 'canopy'
    },
    logging: {
        level: "error" /* LogLevel.ERROR */
    }
};
const canopyConfig = new conf_1.default({
    defaults: CANOPY_CONFIG_DEFAULTS
});
// create logger
const loggerCreator = new logger_1.CerilloLoggerCreator();
const logConfig = {
    level: canopyConfig.get('logging.level'),
    filePath: '/dev/null'
};
const logger = loggerCreator.createLogger(logger_1.Loggers.LOGLEVEL, logConfig);
(0, logger_1.updateGlobalLogger)(logger);
const figletFont = {
    font: font,
};
program
    .version(version_1.VERSION)
    .description('An example CLI for cerillo canopy xbee coordinator functionality')
    .option('-i, --init', 'initialize package on a canopy so it runs on startup')
    .parse(process.argv);
if (program.opts().init) {
    (0, child_process_1.exec)((0, path_1.resolve)(__dirname, '../scripts/init-cerillo-canopy-onboard-files.sh'), (error, stdout, stderr) => {
        if (error) {
            console.log(`error: ${error.message}`);
            return;
        }
        if (stderr) {
            console.log(`stderr: ${stderr}`);
            return;
        }
        console.log(`stdout: ${stdout}`);
    });
}
else {
    // run the main program
    (0, clear_1.default)();
    logger.info(chalk_1.default.cyan(figlet.textSync('cerillo canopy ', figletFont)));
    logger.info(chalk_1.default.magenta(figlet.textSync('v' + version_1.VERSION, figletFont)));
    // eslint-disable-next-line no-unused-vars
    const canopy = new CanopyFirmware_1.CanopyFirmware(canopyConfig);
}
//# sourceMappingURL=main.js.map