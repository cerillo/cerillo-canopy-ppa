"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.VERSION = void 0;
exports.VERSION = '1.2.1-canopy-alpha.1';
//# sourceMappingURL=version.js.map