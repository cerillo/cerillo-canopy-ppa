"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CanopyFirmware = void 0;
const Readline = require('@serialport/parser-readline');
const version_1 = require("./version");
const serialport_1 = __importDefault(require("serialport"));
const color_1 = __importDefault(require("color"));
const types_1 = require("@cerillo/types");
const device_communication_language_1 = require("@cerillo/device-communication-language");
const utils_1 = require("@cerillo/utils");
const xbee_1 = require("@cerillo/xbee");
const logger_1 = require("@cerillo/logger");
const led_driver_1 = require("@cerillo/led-driver");
const LED_ADDR = 0x49;
const LED_BUS = 1;
// eslint-disable-next-line no-unused-vars
var OperationMode;
(function (OperationMode) {
    // eslint-disable-next-line no-unused-vars
    OperationMode[OperationMode["GATEWAY"] = 0] = "GATEWAY";
    // eslint-disable-next-line no-unused-vars
    OperationMode[OperationMode["USB"] = 1] = "USB"; // gateway + act as gadget and stream data over serial connection to a host system
})(OperationMode || (OperationMode = {}));
/**
 * Main class that runs canopy firmware
 *
 * handles serial instructions and routes them to the xbee coordinator through XbeeCoordinator class
 *
 * largely stateless, relies on the XbeeCoordinator class for state of xbee network
 */
class CanopyFirmware {
    constructor(canopyConfig) {
        this.status = types_1.DeviceStatus.STATUS_BOOTING;
        this.operationMode = OperationMode.USB;
        this.init(canopyConfig);
    }
    init(canopyConfig) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            // initialize config which stores a json file on disk for persistance
            // TODO replace Conf with some other package since it isn't production-ready based on initial testing
            this.canopyConfig = canopyConfig;
            // init led driver
            this.ledDriver = yield led_driver_1.DualRgbLedDriver.build(LED_BUS, LED_ADDR);
            // set identifying information from config
            this.serialNumber = this.canopyConfig.get('id.serialNumber');
            this.modelNumber = this.canopyConfig.get('id.modelNumber');
            this.name = this.canopyConfig.get('settings.name');
            this.firmwareVersion = version_1.VERSION;
            this.qcKeyChecksum = ''; // cannot enter qc mode when in this conpfiguration
            this.qcMode = false;
            // set up connection to the xbee with it taking on the role of coordinator
            const coordOptions = {
                serialPort: this.canopyConfig.get('xbee.path'),
                panId: this.canopyConfig.get('xbee.panId'),
                baudRate: this.canopyConfig.get('xbee.baudRate', 9600)
            };
            // set LED to white!
            this.setBooting();
            // If a connection cannot be made to the xbee device, then DON'T catch error
            // and let the program crash
            xbee_1.XBeeCoordinator.buildAsync(coordOptions).then((xbeeCoordinator) => {
                logger_1.logger.info('coordinator done building');
                this.xbeeCoordinator = xbeeCoordinator;
                // setup pipe from xbee traffic to the serial connection
                this.xbeeCoordinator.cdclResponseStrings$.subscribe((deviceResponse) => {
                    this.ledDriver.rightBlink((0, color_1.default)('blue'));
                    this.serialSendChildResponse(deviceResponse);
                });
                // initiate scan on boot
                this.setScanning();
                this.xbeeCoordinator.scan().then(() => {
                    this.setReady();
                }).catch((err) => {
                    logger_1.logger.error('Eror on scan: ', err);
                });
            }).catch((err) => {
                logger_1.logger.error('Failed to initialize xbee coordinator, exiting now');
                logger_1.logger.error(err);
                process.exit(1);
            });
            // initialize the connection to the host computer if available
            const portPath = this.canopyConfig.get('serial.path');
            if (!portPath) {
                throw new Error('Port path for the host controller is not configured!' +
                    'Please add to ~/.config/@cerillo/canopy-nodejs/config.json first');
            }
            this.hostPort = new serialport_1.default(portPath, {
                baudRate: canopyConfig.get('serial.baudRate', 250000),
                autoOpen: false,
                lock: false
            });
            // initialize serial parser and error handler
            const parser = this.hostPort.pipe(new Readline({ delimiter: '\n' }));
            parser.on('data', (data) => {
                this.handleIncomingSerial(data);
            });
            this.hostPort.on('error', function (err) {
                logger_1.logger.error('Error: ', err.message);
            });
            // open the port to the host computer
            (_a = this.hostPort) === null || _a === void 0 ? void 0 : _a.open((err) => {
                logger_1.logger.debug('serial port opened');
                // determine if the canopy is acting as a gateway-only or also as a usb gadget
                if (err) {
                    this.setDisconnected();
                    this.operationMode = OperationMode.GATEWAY;
                    logger_1.logger.error('Error: ', err.message);
                    logger_1.logger.info('Setting up as gateway device');
                }
                else {
                    logger_1.logger.info('Successfully opened port to host system on port ', this.canopyConfig.get('serial.path'));
                    this.operationMode = OperationMode.USB;
                }
            });
        });
    }
    // ==================== Status state update functions ==========
    setDisconnected() {
        this.clearPulse();
        this.ledDriver.setLeftColor((0, color_1.default)('orange'));
        this.status = types_1.DeviceStatus.STATUS_DISCONNECTED;
        this.sendStatus();
    }
    setReady() {
        this.clearPulse();
        this.ledDriver.setLeftColor((0, color_1.default)('green'));
        this.status = types_1.DeviceStatus.STATUS_READY;
        this.sendStatus();
    }
    setQc() {
        this.clearPulse();
        this.qcMode = true;
        this.ledDriver.setLeftColor((0, color_1.default)('blue'));
        this.status = types_1.DeviceStatus.STATUS_QC;
        this.sendStatus();
    }
    setScanning() {
        this.clearPulse();
        // purple pulse
        const currentColor = (0, color_1.default)('purple');
        this.ledDriver.setLeftColor(currentColor);
        this.pulse(currentColor);
        this.status = types_1.DeviceStatus.STATUS_SCANNING;
        this.sendStatus();
    }
    setBooting() {
        this.clearPulse();
        this.ledDriver.setLeftColor((0, color_1.default)('white'));
        this.status = types_1.DeviceStatus.STATUS_BOOTING;
        this.sendStatus();
    }
    getStatusLedHex() {
        const statusLedHex = this.ledDriver.leftColor.hex().replace('#', '0x');
        return statusLedHex;
    }
    getCommsLedHex() {
        const commsLedHex = this.ledDriver.rightColor.hex().replace('#', '0x');
        return commsLedHex;
    }
    sendStatus() {
        return this.serialSendCDCLSelf("x" /* GenericInstructionPrefixes.GET_STATUS */, this.status, this.getStatusLedHex(), this.getCommsLedHex());
    }
    pulse(color) {
        const maxRgb = color.rgbNumber();
        let down = true;
        // only start a new pulse interval if one doesn't exist
        // otherwise one will get lost to the ether and become uncancellable
        if (!this.pulseInterval) {
            this.pulseInterval = setInterval(() => {
                this.ledDriver.setLeftColor(color);
                // handle color change
                if (down) {
                    color = color.darken(0.1);
                }
                else {
                    color = color.lighten(0.1);
                }
                // handle direction changes
                if (color.rgbNumber() >= maxRgb) {
                    down = true;
                }
                if (color.rgbNumber() <= 0) {
                    down = false;
                }
            }, 10);
        }
    }
    clearPulse() {
        clearInterval(this.pulseInterval);
        this.pulseInterval = undefined;
    }
    //  =================== Command Handlers =======================
    handleIncomingSerial(data) {
        return __awaiter(this, void 0, void 0, function* () {
            logger_1.logger.info('Incoming string from serial port: ', data);
            this.ledDriver.rightBlink((0, color_1.default)('purple'));
            // echo it back to the port for diagnostic purposes
            yield this.serialSendStr(data + '\n');
            const pkt = device_communication_language_1.GenericMsgParser.parseCDCLCommand(data);
            logger_1.logger.info('Incoming data packet from serial port: ', pkt);
            const validPacket = this.filterPackets(pkt);
            if (!validPacket) {
                logger_1.logger.warn('Discarded packet because found to be invalid');
                return;
            }
            ;
            // check if this is packet meant for a child device
            if (pkt.serialNumber !== '' && pkt.serialNumber !== this.serialNumber) {
                try {
                    // Forward the packet to the device; its response will be auto-routed
                    // straight to Serial by the XBeeCoordinator.cdclResponseStrings$ pipe
                    this.ledDriver.rightBlink((0, color_1.default)('blue'));
                    logger_1.logger.info('received packet meant for an xbee-connected device');
                    this.xbeeSend(pkt);
                }
                catch (error) {
                    logger_1.logger.error('Failed to send packet over xbee');
                    logger_1.logger.error(error);
                }
            }
            else { // must be meant for the Canopy
                if (pkt.serialNumber === '')
                    pkt.serialNumber = this.serialNumber;
                switch (pkt.prefix) {
                    case "x" /* GenericInstructionPrefixes.GET_STATUS */:
                        this.handleStatusResponse(pkt);
                        break;
                    case "i" /* GenericInstructionPrefixes.GET_INFO */:
                        this.handleInfoResponse(pkt);
                        break;
                    case "h" /* GenericInstructionPrefixes.GET_CHILDREN */:
                        this.handleChildrenResponse(pkt);
                        break;
                    case "k" /* GenericInstructionPrefixes.GET_QC_MODE_KEY */:
                        this.handleQcModeKeyResponse(pkt);
                        break;
                    case "G" /* GenericInstructionPrefixes.GET_SETTINGS */:
                        this.handleGetSettings(pkt);
                        break;
                    case "g" /* GenericInstructionPrefixes.SET_SETTINGS */:
                        this.handleSetSettings(pkt);
                        break;
                    case "Q" /* GenericInstructionPrefixes.TURN_QC_MODE_ON */:
                        this.handleQcModeOn(pkt);
                        break;
                    case "q" /* GenericInstructionPrefixes.TURN_QC_MODE_OFF */:
                        this.handleQcModeOff(pkt);
                        break;
                    case "n" /* GenericInstructionPrefixes.SET_SERIAL_NUMBER */:
                        this.handleSetSerialNumber(pkt);
                        break;
                    case "N" /* GenericInstructionPrefixes.SET_MODEL_NUMBER */:
                        this.handleSetModelNumber(pkt);
                        break;
                    default:
                        break;
                }
            }
        });
    }
    handleQcModeKeyResponse(pkt) {
        const qcKey = this.randomFixedInteger(32);
        this.qcKeyChecksum = String(device_communication_language_1.GenericMsgParser.calcChecksum(qcKey));
        return this.serialSendCDCL(pkt, qcKey);
    }
    handleGetSettings(pkt) {
        const name = this.canopyConfig.get('settings.name');
        const settingsStr = `n${name}`;
        return this.serialSendCDCL(pkt, settingsStr);
    }
    handleSetSettings(pkt) {
        return __awaiter(this, void 0, void 0, function* () {
            const settings = device_communication_language_1.GenericMsgParser.parseSettingsStr(pkt.msg);
            if (settings.name) {
                this.canopyConfig.set('settings.name', settings.name);
            }
            this.name = this.canopyConfig.get('settings.name');
            const settingsStr = `n${this.name}`;
            return this.serialSendCDCL(pkt, settingsStr);
        });
    }
    handleQcModeOn(pkt) {
        const qcKeyChecksumProvided = pkt.msg;
        if (qcKeyChecksumProvided === this.qcKeyChecksum && this.qcKeyChecksum !== '') {
            logger_1.logger.info('Entering QC Mode');
            // valid check sum
            this.setQc();
            // TODO refactor success and error indicators to CDCL lib
            return this.serialSendCDCL(pkt, '0'); // indicates faulty qc key
        }
        else {
            logger_1.logger.info('checksum invalid or not provided');
            this.qcKeyChecksum = ''; // reset the checksum - user must ask for key again
            return this.serialSendCDCL(pkt, '1'); // indicates faulty qc key
        }
    }
    handleSetModelNumber(pkt) {
        var _a;
        if (this.qcMode) {
            const modelNumber = (_a = pkt === null || pkt === void 0 ? void 0 : pkt.msg) === null || _a === void 0 ? void 0 : _a.trim();
            if (modelNumber) {
                logger_1.logger.info('Updating model number to ', modelNumber);
                this.canopyConfig.set('id.modelNumber', modelNumber);
                this.modelNumber = modelNumber;
                return this.serialSendCDCL(pkt, modelNumber);
            }
            else {
                logger_1.logger.error('Not a valid model number, ', modelNumber);
                return this.serialSendCDCL(pkt, '1');
            }
        }
        else {
            logger_1.logger.error('Cannot change model number when not in qcMode');
            return this.serialSendCDCL(pkt, '1'); // indicates faulty qc key
        }
    }
    handleSetSerialNumber(pkt) {
        var _a;
        if (this.qcMode) {
            const serialNumber = (_a = pkt === null || pkt === void 0 ? void 0 : pkt.msg) === null || _a === void 0 ? void 0 : _a.trim();
            if (serialNumber) {
                logger_1.logger.info('Updating serial number to ', serialNumber);
                this.canopyConfig.set('id.serialNumber', serialNumber);
                this.serialNumber = serialNumber;
                return this.serialSendCDCL(pkt, serialNumber);
            }
            else {
                logger_1.logger.error('Not a valid serial number, ', serialNumber);
                return this.serialSendCDCL(pkt, '1');
            }
        }
        else {
            return this.serialSendCDCL(pkt, '1'); // indicates faulty qc key
        }
    }
    handleQcModeOff(pkt) {
        this.qcMode = false;
        return this.serialSendCDCL(pkt, '0');
    }
    handleStatusResponse(pkt) {
        return __awaiter(this, void 0, void 0, function* () {
            logger_1.logger.info('Canopy sending status');
            return this.serialSendCDCL(pkt, this.status, this.getStatusLedHex());
        });
    }
    handleInfoResponse(pkt) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            logger_1.logger.info('Canopy sending info');
            return this.serialSendCDCL(pkt, `m${this.modelNumber} f${this.firmwareVersion} n"${(_a = this.name) !== null && _a !== void 0 ? _a : ''}"`);
        });
    }
    handleChildrenResponse(pkt) {
        return __awaiter(this, void 0, void 0, function* () {
            logger_1.logger.info('Canopy sending children');
            const children = yield this.getChildDevices();
            return this.serialSendCDCL(pkt, children);
        });
    }
    serialSendCDCL(inPkt, ...str) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this.hostPort) {
                logger_1.logger.error('Cannot send packet when USB host not connected');
                return false;
            }
            const strSend = `:${inPkt.serialNumber}${inPkt.cmdId ? `*${inPkt.cmdId} ` : ' '} ${inPkt.prefix}${str.join(' ')}\n`;
            logger_1.logger.info('Sending string over serial connection: ', strSend);
            return this.serialSendStr(strSend);
        });
    }
    serialSendCDCLSelf(prefix, ...str) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this.hostPort) {
                logger_1.logger.error('Cannot send packet when USB host not connected');
                return false;
            }
            const strSend = `:${this.serialNumber} ${prefix}${str.join(' ')}\n`;
            logger_1.logger.info('Sending string over serial connection: ', strSend);
            return this.serialSendStr(strSend);
        });
    }
    serialSendStr(str) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this.hostPort) {
                throw new Error('Cannot send packet when USB host not connected');
            }
            return new Promise((resolve, reject) => {
                this.hostPort.write(str, (error) => {
                    if (error) {
                        logger_1.logger.error(error);
                        this.ledDriver.rightBlink((0, color_1.default)('red'));
                        reject(error);
                    }
                    else {
                        this.ledDriver.rightBlink((0, color_1.default)('purple'));
                        resolve(true);
                    }
                });
            });
        });
    }
    // TODO move to utils?
    randomFixedInteger(length) {
        let randomIntString = '';
        for (let index = 0; index < length; index++) {
            const r = Math.floor(Math.random() * 32);
            if (r > 25) {
                randomIntString += String.fromCharCode('0'.charCodeAt(0) + r - 26);
            }
            else {
                randomIntString += String.fromCharCode('a'.charCodeAt(0) + r);
            }
        }
        return randomIntString;
    }
    serialSendChildResponse(message) {
        if (!this.hostPort) {
            throw new Error('Cannot send packet when USB host not connected');
        }
        return this.hostPort.write(message + '\n');
    }
    //  =================== End Device Command Handlers =================
    xbeeSend(packet) {
        try {
            if (this.xbeeCoordinator) {
                this.xbeeCoordinator.sendPktAndGetResponses(packet);
            }
            else {
                this.ledDriver.rightBlink((0, color_1.default)('red'));
                logger_1.logger.error('Cannot send xbee packet before coordinator initialized');
            }
        }
        catch (error) {
            this.ledDriver.rightBlink((0, color_1.default)('red'));
            logger_1.logger.error('Cannot send xbee packet before coordinator initialized');
        }
    }
    /**
     * Scans for devices, returns child devices as serialized object
     */
    getChildDevices() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.xbeeCoordinator) {
                // send scanning status
                this.setScanning();
                try {
                    // scan for devices - or get any ongoing scan
                    const devices = yield this.xbeeCoordinator.scan(3000); // short 3-second scan
                    const devicesAsJson = JSON.stringify(devices, utils_1.ObjectUtils.mapToJsonReplacer);
                    this.setReady();
                    return devicesAsJson;
                }
                catch (error) {
                    this.setReady();
                    return JSON.stringify(new Map(), utils_1.ObjectUtils.mapToJsonReplacer);
                }
            }
            else {
                logger_1.logger.error('Getting children before xbee coordinator initialized, sending empty map');
                const devicesAsJson = JSON.stringify(new Map(), utils_1.ObjectUtils.mapToJsonReplacer);
                return devicesAsJson;
            }
        });
    }
    // ============= Helpers ===============================================
    // returns true if valid packet to be processed
    filterPackets(packet) {
        if (!packet) {
            return false;
        }
        if (packet.prefix.length > 2) {
            logger_1.logger.info('Discarding packet because prefix does not contain instruction');
            return false;
        }
        return true;
    }
}
exports.CanopyFirmware = CanopyFirmware;
//# sourceMappingURL=CanopyFirmware.js.map