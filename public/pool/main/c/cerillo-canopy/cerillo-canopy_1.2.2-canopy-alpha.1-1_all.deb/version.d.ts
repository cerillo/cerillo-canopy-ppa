export declare const VERSION = "1.2.1-canopy-alpha.1";
//# sourceMappingURL=version.d.ts.map