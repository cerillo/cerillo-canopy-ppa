import Conf from 'conf';
import { LogLevel } from '@cerillo/types';
export interface ICanopyConfig {
    id: {
        serialNumber: string;
        modelNumber: string;
    };
    xbee: {
        path?: string;
        panId?: string;
        baudRate?: number;
    };
    serial: {
        path: string;
        baudRate: number;
    };
    settings: {
        name: string;
    };
    logging: {
        level: LogLevel;
    };
}
/**
 * Main class that runs canopy firmware
 *
 * handles serial instructions and routes them to the xbee coordinator through XbeeCoordinator class
 *
 * largely stateless, relies on the XbeeCoordinator class for state of xbee network
 */
export declare class CanopyFirmware {
    private canopyConfig;
    private hostPort;
    private serialNumber;
    private modelNumber;
    private name;
    private status;
    private operationMode;
    private firmwareVersion;
    private xbeeCoordinator?;
    private qcKeyChecksum;
    private qcMode;
    private ledDriver;
    private pulseInterval?;
    constructor(canopyConfig: Conf<ICanopyConfig>);
    private init;
    private setDisconnected;
    private setReady;
    private setQc;
    private setScanning;
    private setBooting;
    private getStatusLedHex;
    private getCommsLedHex;
    private sendStatus;
    private pulse;
    private clearPulse;
    private handleIncomingSerial;
    private handleQcModeKeyResponse;
    private handleGetSettings;
    private handleSetSettings;
    private handleQcModeOn;
    private handleSetModelNumber;
    private handleSetSerialNumber;
    private handleQcModeOff;
    private handleStatusResponse;
    private handleInfoResponse;
    private handleChildrenResponse;
    private serialSendCDCL;
    private serialSendCDCLSelf;
    private serialSendStr;
    private randomFixedInteger;
    private serialSendChildResponse;
    private xbeeSend;
    /**
     * Scans for devices, returns child devices as serialized object
     */
    private getChildDevices;
    private filterPackets;
}
//# sourceMappingURL=CanopyFirmware.d.ts.map